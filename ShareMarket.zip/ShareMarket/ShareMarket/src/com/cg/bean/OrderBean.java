package com.cg.bean;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name = "order_master")
public class OrderBean {
	
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "Id_generator")
	@SequenceGenerator(name="Id_generator", sequenceName = "stock_seq", allocationSize=1)
	@Column(name = "order_id")
	private int orderId ;
	
	@Column(name = "stock")
	private String stockName;
	
	@Column(name = "quote")
	private double quote;
	
	@Column(name = "order_amount")
	private double orderAmount;
	
	@Column(name = "commission")
	private double commission;

	public OrderBean() {
		super();
	}

	public OrderBean(int orderId, String stockName, double quote,
			double orderAmount, double commission) {
		super();
		this.orderId = orderId;
		this.stockName = stockName;
		this.quote = quote;
		this.orderAmount = orderAmount;
		this.commission = commission;
	}

	public int getOrderId() {
		return orderId;
	}

	public void setOrderId(int orderId) {
		this.orderId = orderId;
	}

	public String getStockName() {
		return stockName;
	}

	public void setStockName(String stockName) {
		this.stockName = stockName;
	}

	public double getQuote() {
		return quote;
	}

	public void setQuote(double quote) {
		this.quote = quote;
	}

	public double getOrderAmount() {
		return orderAmount;
	}

	public void setOrderAmount(double orderAmount) {
		this.orderAmount = orderAmount;
	}

	public double getCommission() {
		return commission;
	}

	public void setCommission(double commission) {
		this.commission = commission;
	}
	
	

}
